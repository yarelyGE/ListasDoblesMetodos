package app;

import doublelinkedlist.DoubleLinkedList;

public class App {

	public static void main(String[] args) {
		
		DoubleLinkedList<String> names = new DoubleLinkedList<String>(); // <-- GUARDA CADENAS
		DoubleLinkedList<String> names2 = new DoubleLinkedList<String>();
		DoubleLinkedList<String> names3 = new DoubleLinkedList<String>();
		DoubleLinkedList<Integer> num = new DoubleLinkedList<Integer>();
		
		names.addEnd("Cecilia");
		names.addEnd("Yarely");
		names.addEnd("Angy");
		names.addEnd("Karla");
		names.addStart("Angelica");
		names.addStart("Roxx");
		names.addStart("Alejandra");
		names.addStart("Anna");
		names.addStart("Melissa");
		names.addStart("Fernanda");
		
		names2.addEnd("Cecilia");
		names2.addEnd("Yarely");
		names2.addEnd("Angy");
		names2.addEnd("Karla");
		names2.addStart("Angelica");
		names2.addStart("Roxx");
		names2.addStart("Alejandra");
		names2.addStart("Anna");
		names2.addStart("Melissa");
		names2.addStart("Fernanda");
		
		names3.addEnd("Anna");
		names3.addEnd("Yarely");
		names3.addEnd("Angy");
		names3.addEnd("Anna");
		names3.addStart("Angelica");
		names3.addStart("Roxx");
		names3.addStart("Alejandra");
		names3.addStart("Anna");
		names3.addStart("Melissa");
		names3.addStart("Anna");
		
		num.addEnd(4);
		num.addEnd(3);
		num.addEnd(2);
		num.addEnd(1);
		num.addStart(10);
		num.addStart(9);
		num.addStart(8);
		num.addStart(7);
		num.addStart(6);
		num.addStart(5);
		
/*		names.removeafter("Anna");
		names.removebefore("Anna");
		
		for(String name: names) 
		{
			System.out.println(name);
		}
		
		System.out.println("");
		System.out.println("Search: " + names.Search("Roxx"));
		System.out.println("Remove: " + names.remove("Yarely"));
		names.replace("Roxx", "Jacqueline");
		
		System.out.println("");
		names.isempty();
		
		System.out.println("");
		names.removefirst();
		names.removelast();
		System.out.println("-Start-");
		names.pronterstart();
		
		System.out.println("");
//		names.clear();// <-- QUITAR COMENTARIOS PARA PROVAR
		names.isempty();
		
		System.out.println("");
		names.getfirst();
		names.getlast();
		
		System.out.println("");
		System.out.println("-End-");
		names.pronterend();
		
		System.out.println("");
		System.out.println("Tama�o de la lista: " + names.size() + " posiciones");
		System.out.println("Posicion de la busqueda " + names.indexof("Angelica"));*/
		
		System.out.println("Son iguales: " + names.iguales(names, names2));
		System.out.println("Encontrado?: " + names.existeelemento("Roxx"));
		System.out.println("Ocurrencias: " + names3.ocurrencia("Anna"));
		System.out.println("Suma: " + num.suma(num));
		System.out.println("Maximo: " + num.maximo());
	}

}